#nomor-1
stok = [15 , 50, 30, 25, 40]
stok.append(100)
print(stok)

#nomor-2
stok = [15 , 50, 30, 25, 40]
stok.insert(2, 75)
print(stok)

#nomor-3
stok = [15 , 50, 30, 25, 40]
stok.sort(reverse = True)
print(stok)

#nomor-4 
stok = [15 , 50, 30, 25, 40]
rataRata = sum(stok) / len(stok)
print(rataRata)

print ('setelah perubahan yangfg dilakukan :')

#nomor-5 
stok = [15 , 50, 30, 25, 40]
stok.append(100)
stok.insert(2, 75)
stok.sort(reverse = True)
rataRata = sum(stok) / len(stok)

print (stok)
print (rataRata)