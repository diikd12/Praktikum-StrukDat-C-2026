def registrasi_gadget(merk, tipe, harga, sn):
    if harga < 1000000:
        print ('harga tidak valid!')
        return None
    
    if len(sn) < 5:
        print ('serial number tidak valid!')
        return None
    return{
        "merk" : merk,
        "tipe" : tipe,
        "harga" : harga,
        "sn" : sn
    }
    for i in range (3):
        merk = input('masukkan merk gadget: ')
        tipe = input('masukkan tipe gadget: ')
        harga = inp(input('masukan harga gadget: '))
        sn = input